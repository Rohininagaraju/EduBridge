package service;

public interface AdminService {
    void listUsers();
    void listCards();
    void deactivateCard(int cardId);
    void issueCard(String userName);
    void handleAdminActions();
}
