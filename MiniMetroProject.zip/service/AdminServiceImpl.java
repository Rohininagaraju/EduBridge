package service;

import java.util.Scanner;
import repository.AdminRepo;

public class AdminServiceImpl implements AdminService {
    private AdminRepo adminRepo;
    private Scanner sc;

    public AdminServiceImpl() {
        this.adminRepo = new AdminRepo();
        this.sc = new Scanner(System.in);
    }

    @Override
    public void listUsers() {
        adminRepo.listUsers();
    }

    @Override
    public void listCards() {
        adminRepo.listCards();
    }

    @Override
    public void deactivateCard(int cardId) {
        adminRepo.deactivateCard(cardId);
    }

    @Override
    public void issueCard(String userName) {
        int userId = adminRepo.getUserIdByName(userName);
        if (userId == -1) {
            System.out.println("User not found. Please check the username.");
        } else {
            adminRepo.issueCard(userId);
        }
    }

    @Override
    public void handleAdminActions() {
        System.out.println("1. List Users\n2. List Cards\n3. Deactivate Card\n4. Issue Card");
        int adminChoice = sc.nextInt();

        switch (adminChoice) {
            case 1 -> listUsers();
            case 2 -> listCards();
            case 3 -> {
                System.out.println("Enter card ID to deactivate");
                int cardId = sc.nextInt();
                deactivateCard(cardId);
            }
            case 4 -> {
                System.out.println("Enter username to issue card");
                String userName = sc.next();
                issueCard(userName);
            }
            default -> System.out.println("Invalid choice.");
        }
    }
}
