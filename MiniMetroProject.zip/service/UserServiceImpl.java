package service;

import java.util.Scanner;
import repository.UserRepo;

public class UserServiceImpl implements UserService {
    private UserRepo userRepo;
    private Scanner sc;

    public UserServiceImpl() {
        this.userRepo = new UserRepo();
        this.sc = new Scanner(System.in);
    }

    @Override
    public void registerUser(String name, String password) {
        userRepo.registerUser(name, password);
    }

    @Override
    public void rechargeCard(int cardId, double amount, String userName) {
        int userId = userRepo.getUserIdByName(userName);
        if (userId == -1) {
            System.out.println("User not found. Please register first.");
            return;
        }
        userRepo.rechargeCardByName(userName,amount);
    }

    @Override
    public void sendDeactivateRequest(String userName) {
        userRepo.sendDeactivateRequest(userName);
    }

    @Override
    public void checkBalance(int cardId) {
        userRepo.checkBalance(cardId);
    }

    @Override
    public void handleUserActions() {
        System.out.println("1. Recharge Card\n2. Send Deactivate Request\n3. Check Balance");
        int userChoice = sc.nextInt();

        switch (userChoice) {
            case 1 -> {
                System.out.println("Enter your username");
                String userName = sc.next();
                System.out.println("Enter card ID and amount to recharge");
                int cardId = sc.nextInt();
                double amount = sc.nextDouble();
                rechargeCard(cardId, amount, userName);
            }
            case 2 -> {
                System.out.println("Enter your username");
                String userName = sc.next();
                sendDeactivateRequest(userName);
            }
            case 3 -> {
                System.out.println("Enter card ID");
                int cardId = sc.nextInt();
                checkBalance(cardId);
            }
            default -> System.out.println("Invalid choice.");
        }
    }
}
