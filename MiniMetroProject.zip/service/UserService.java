package service;


public interface UserService {
    void registerUser(String name, String password);
    void rechargeCard(int cardId, double amount, String userName);
    void sendDeactivateRequest(String userName);
    void checkBalance(int cardId);
    void handleUserActions();
}
