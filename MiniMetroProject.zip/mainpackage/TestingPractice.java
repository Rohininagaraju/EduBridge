package mainpackage;

import java.util.Scanner;
import service.UserService;
import service.UserServiceImpl;
import service.AdminService;
import service.AdminServiceImpl;

public class TestingPractice {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UserService userService = new UserServiceImpl();
        AdminService adminService = new AdminServiceImpl();

        int input;

        do {
            System.out.println("\nWelcome to Metro app");
            System.out.println("Click 1 to register");
            System.out.println("Click 2 if already a member");
            System.out.println("Click 0 to exit");
            input = sc.nextInt();

            switch (input) {
                case 1:
                    System.out.println("Enter the details - name, password");
                    String name = sc.next();
                    String password = sc.next();
                    userService.registerUser(name, password);
                    break;

                case 2:
                    System.out.println("Are you a User or Admin? Enter u for user and a for admin");
                    char choice = sc.next().charAt(0);

                    if (choice == 'u') {
                        userService.handleUserActions();
                    } else if (choice == 'a') {
                        adminService.handleAdminActions();
                    } else {
                        System.out.println("Invalid choice. Please try again.");
                    }
                    break;

                case 0:
                    System.out.println("Thank you for using Metro app. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (input != 0);

        sc.close();
    }
}
