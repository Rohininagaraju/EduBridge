package dbconnection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class SqlConnection {
    public static Connection getMyConnection() {
        Connection con = null;
        try {
            FileInputStream fis = new FileInputStream("loginprop.properties");
            Properties prop = new Properties();
            prop.load(fis);

            // Load driver class
            Class.forName(prop.getProperty("drivername"));

            // Establish the connection
            con = DriverManager.getConnection(
                prop.getProperty("url"),
                prop.getProperty("username"),
                prop.getProperty("password")
            );
        } catch (FileNotFoundException e) {
            System.err.println("Properties file not found.");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Error reading properties file.");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.err.println("Database driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error establishing database connection.");
            e.printStackTrace();
        }

        return con; // Return the connection
    }
}
