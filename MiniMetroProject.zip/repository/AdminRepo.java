package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import dbconnection.SqlConnection;

public class AdminRepo {

	 public void listUsers() {
	        try (
	        		Connection con = SqlConnection.getMyConnection()) {
	            String query = "SELECT * FROM practice";
	            PreparedStatement stmt = con.prepareStatement(query);
	            ResultSet rs = stmt.executeQuery();

	            System.out.println("Registered Users:");
	            while (rs.next()) {
	                System.out.println("Name: " + rs.getString("name"));
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	 public void listCards() {
		    try (Connection con = SqlConnection.getMyConnection()) {
		        String query = """
		            SELECT c.id, c.balance, c.active, p.name 
		            FROM cards c 
		            JOIN practice p ON c.user_id = p.id
		        """;
		        PreparedStatement stmt = con.prepareStatement(query);
		        ResultSet rs = stmt.executeQuery();

		        System.out.println("Cards:");
		        while (rs.next()) {
		            System.out.printf("Card ID: %d, User: %s, Balance: %.2f, Active: %b%n",
		                              rs.getInt("id"), rs.getString("name"),
		                              rs.getDouble("balance"), rs.getBoolean("active"));
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}


	    public void deactivateCard(int cardId) {
	        try (Connection con = SqlConnection.getMyConnection()) {
	            String query = "UPDATE cards SET active = false WHERE id = ?";
	            PreparedStatement stmt = con.prepareStatement(query);
	            stmt.setInt(1, cardId);
	            int res = stmt.executeUpdate();

	            System.out.println(res > 0 ? "Card deactivated successfully." : "Failed to deactivate card.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public void issueCard(int userId) {
	        try (Connection con = SqlConnection.getMyConnection()) {
	            String query = "INSERT INTO cards (user_id, balance, active) VALUES (?, 0, true)";
	            PreparedStatement stmt = con.prepareStatement(query);
	            stmt.setInt(1, userId);
	            int res = stmt.executeUpdate();

	            System.out.println(res > 0 ? "Card issued successfully." : "Failed to issue card.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }


	    public void handleAdminActions(Scanner sc) {
	        System.out.println("1. List Users\n2. List Cards\n3. Deactivate Card\n4. Issue Card");
	        int adminChoice = sc.nextInt();

	        switch (adminChoice) {
	            case 1 -> listUsers();
	            case 2 -> listCards();
	            case 3 -> {
	                System.out.println("Enter card ID to deactivate");
	                int cardId = sc.nextInt();
	                deactivateCard(cardId);
	            }
	            case 4 -> {
	                System.out.println("Enter username to issue card");
	                String userName = sc.next();
	                int userId = getUserIdByName(userName);

	                if (userId == -1) {
	                    System.out.println("User not found. Please check the username.");
	                } else {
	                    issueCard(userId); // Pass the correct userId
	                }
	            }
	            default -> System.out.println("Invalid choice.");
	        }
	    }
	    public int getUserIdByName(String userName) {
	        try (Connection con = SqlConnection.getMyConnection()) {
	            String query = "SELECT id FROM practice WHERE name = ?";
	            PreparedStatement stmt = con.prepareStatement(query);
	            stmt.setString(1, userName);
	            ResultSet rs = stmt.executeQuery();

	            if (rs.next()) {
	                return rs.getInt("id"); // Return the userId
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return -1; // Return -1 if user is not found
	    }


	}

