package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import dbconnection.SqlConnection;

public class UserRepo {
	 public void registerUser(String name, String password) {
	        try (Connection con = SqlConnection.getMyConnection()) {
	            String query = "INSERT INTO practice (name, password) VALUES (?, ?)";
	            PreparedStatement stmt = con.prepareStatement(query);
	            stmt.setString(1, name);
	            stmt.setString(2, password);
	            int res = stmt.executeUpdate();

	            System.out.println(res > 0 ? "Registration successful." : "Registration failed.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	 public void rechargeCardByName(String userName, double amount) {
		    try (Connection con = SqlConnection.getMyConnection()) {
		        
		        String getUserIdQuery = "SELECT id FROM practice WHERE name = ?";
		        PreparedStatement getUserIdStmt = con.prepareStatement(getUserIdQuery);
		        getUserIdStmt.setString(1, userName);
		        ResultSet userIdRs = getUserIdStmt.executeQuery();

		        if (!userIdRs.next()) {
		            System.out.println("User not found. Please register first.");
		         //   return;
		        }
		        int userId = userIdRs.getInt("id");

		        
		        String getCardIdQuery = "SELECT id FROM cards WHERE user_id = ?";
		        PreparedStatement getCardIdStmt = con.prepareStatement(getCardIdQuery);
		        getCardIdStmt.setInt(1, userId);
		        ResultSet cardIdRs = getCardIdStmt.executeQuery();

		        if (!cardIdRs.next()) {
		            System.out.println("No card associated with this user.");
		            return;
		        }
		        int cardId = cardIdRs.getInt("id");

		       
		        String rechargeQuery = "UPDATE cards SET balance = balance + ? WHERE id = ?";
		        PreparedStatement rechargeStmt = con.prepareStatement(rechargeQuery);
		        rechargeStmt.setDouble(1, amount);
		        rechargeStmt.setInt(2, cardId);

		        int res = rechargeStmt.executeUpdate();
		        System.out.println(res > 0 ? "Recharge successful!" : "Recharge failed.");
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}



	    public void sendDeactivateRequest(String userName) {
	        try (Connection con = SqlConnection.getMyConnection()) {
	            String query = "INSERT INTO deactivate_requests (user_name) VALUES (?)";
	            PreparedStatement stmt = con.prepareStatement(query);
	            stmt.setString(1, userName);
	            int res = stmt.executeUpdate();

	            System.out.println(res > 0 ? "Deactivate request sent successfully." : "Failed to send deactivate request.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public void checkBalance(int cardId) {
	        try (
	        		Connection con = SqlConnection.getMyConnection()) {
	            String query = "SELECT balance FROM cards WHERE id = ?";
	            PreparedStatement stmt = con.prepareStatement(query);
	            stmt.setInt(1, cardId);
	            ResultSet rs = stmt.executeQuery();

	            if (rs.next()) {
	                System.out.println("Current Balance: " + rs.getDouble("balance"));
	            } else {
	                System.out.println("Card not found.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    public int getUserIdByName(String name) {
	        try (Connection con = SqlConnection.getMyConnection()) {
	            String query = "SELECT id FROM practice WHERE name = ?";
	            PreparedStatement stmt = con.prepareStatement(query);
	            stmt.setString(1, name);
	            ResultSet rs = stmt.executeQuery();
	            if (rs.next()) {
	                return rs.getInt("id");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return -1;  
	    }


	    public void handleUserActions(Scanner sc) {
	        System.out.println("1. Recharge Card (Enter username)\n2. Send Deactivate Request\n3. Check Balance");
	        int userChoice = sc.nextInt();

	        switch (userChoice) {
	            case 1 -> {
	                System.out.println("Enter your username");
	                String userName = sc.next();

	                System.out.println("Enter the amount to recharge");
	                double amount = sc.nextDouble();

	                rechargeCardByName(userName, amount); 
	            }
	            case 2 -> {
	                System.out.println("Enter your username");
	                String userName = sc.next();
	                sendDeactivateRequest(userName);
	            }
	            case 3 -> {
	                System.out.println("Enter card ID");
	                int cardId = sc.nextInt();
	                checkBalance(cardId);
	            }
	            default -> System.out.println("Invalid choice.");
	        }
	    }

	    

	}


