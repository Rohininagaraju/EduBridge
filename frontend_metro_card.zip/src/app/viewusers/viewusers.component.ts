import { Component, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewusers',
  standalone: false,
  
  templateUrl: './viewusers.component.html',
  styleUrl: './viewusers.component.css'
})
export class ViewusersComponent implements OnInit{

  usersList:any;
  searchText:any;
count=5;
p=1;
  constructor(
    private userService:UserService,
    private router:Router
  ){

  }
  ngOnInit(): void {
    this.userService.getAllUsers().subscribe(data => {

      this.usersList = data;
    }
    )}
    deleteUser(userId:any)
    {
      this.userService.deleteUser(userId).subscribe(data => {

        this.usersList=data;
      })
}
updateUser(userId:any)
{
  this.router.navigate(['updateuserurl',userId])
}
Onback(){
  this.router.navigate(['adminhomeurl']);
}
findUser(){
  this.userService.search(this.searchText).subscribe(
    (response:any)=>
    {
      this.usersList=response;
    }
  )
}
}

