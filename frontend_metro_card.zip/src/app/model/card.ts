export class Card{
    cardId!:number;
	 balance:number;
	status:string;
	issue:Date;
	expiry:Date;
    userId:number;

    constructor(
//        cardId: number,
        balance:number,
       status:string,
       userId:number,
       issue:Date,
       expiry:Date)
       {  
   //this.cardId=cardId;
        this.balance=balance;
        this.status=status;
        this.issue=issue;
        this.expiry=expiry;
        this.userId=userId;
       }
	
}