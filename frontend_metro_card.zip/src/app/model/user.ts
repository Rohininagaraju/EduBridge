export class User {
    userId:number;
    username:string;
    userPassword:string;
    phone:string;
    emailId:string;
    city:string;
    role:String;

    constructor(
        userId:number,
        username:string,
        userPassword:string,
        phone:string,
        emailId:string,
        city:string,
        role:string,
    )
    {
        this.userId=userId;
        this.username=username;
        this.userPassword=userPassword;
        this.phone=phone;
        this.emailId=emailId;
        this.city=city;
        this.role=role;
    }


}