import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { SignupComponent } from './signup/signup.component';
import { ViewusersComponent } from './viewusers/viewusers.component';
import { UpdateuserComponent } from './updateuser/updateuser.component';
import { LoginComponent } from './login/login.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { UseractionsComponent } from './useractions/useractions.component';
import { ViewcardsComponent } from './viewcards/viewcards.component';

const routes: Routes = [{path:"",component:WelcomeComponent},
  {path:"usersignupUrl",component:SignupComponent},
  {path:"viewusersUrl",component:ViewusersComponent},
  {path:"updateuserurl/:userId",component:UpdateuserComponent},
  {path:"usersigninUrl",component:LoginComponent},
  {path:"adminhomeurl/:userId",component:AdminhomeComponent},
  {path:"userhomeurl/:userId",component:UserhomeComponent},
  {path:"welcomepageurl",component:WelcomeComponent},
  {path:"useractionurl",component:UseractionsComponent},
  {path:"viewcardsurl",component:ViewcardsComponent},
  {path:"adminhomeurl",component:AdminhomeComponent}

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
