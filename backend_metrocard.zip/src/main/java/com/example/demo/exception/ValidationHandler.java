	package com.example.demo.exception;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.validation.FieldError;
	import org.springframework.web.bind.MethodArgumentNotValidException;
	import org.springframework.web.bind.annotation.ControllerAdvice;
	import org.springframework.web.bind.annotation.ExceptionHandler;

	import java.util.HashMap;
	import java.util.Map;

	@ControllerAdvice
	public class ValidationHandler {

	    // Handle validation errors
	    @ExceptionHandler(MethodArgumentNotValidException.class)
	    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
	        Map<String, String> errors = new HashMap<>();

	        // Extract error messages from FieldErrors
	        ex.getBindingResult().getAllErrors().forEach((error) -> {
	            String fieldName = ((FieldError) error).getField();
	            String errorMessage = error.getDefaultMessage();
	            errors.put(fieldName, errorMessage);
	        });

	        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	    }

	    // Handle custom exceptions like ResourceNotFoundException
	    @ExceptionHandler(ResourceNotFoundException.class)
	    public ResponseEntity<Map<String, Object>> handleResourceNotFoundException(ResourceNotFoundException ex) {
	        Map<String, Object> errorDetails = new HashMap<>();
	        errorDetails.put("message", ex.getMessage());
	        errorDetails.put("resourceName", ex.getResourceName());
	        errorDetails.put("fieldName", ex.getFieldName());
	        errorDetails.put("fieldValue", ex.getFieldValue());

	        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	    }

	    // Handle other exceptions (optional)
	    @ExceptionHandler(Exception.class)
	    public ResponseEntity<Map<String, String>> handleGeneralException(Exception ex) {
	        Map<String, String> errorDetails = new HashMap<>();
	        errorDetails.put("message", "An unexpected error occurred");
	        errorDetails.put("error", ex.getMessage());

	        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}



