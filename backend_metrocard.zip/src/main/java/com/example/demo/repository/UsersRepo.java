package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Users;

@Repository
public interface UsersRepo extends JpaRepository<Users,Integer>{
	
	public  Users findByUsernameAndUserPassword(String username,String userPassword);
	
	public Users findByUsername(String username);
	
	public Users findByCity(String city);
	
	public Users findByPhone(String phone);
	
	public Users findByEmailId(String email);
	
	@Query(value = "select * from usertable u where u.user_name like %?1% or u.phone like %?1% or u.city like %?1% or u.email like %?1%",nativeQuery = true)
	public List<Users> searchUsers(String searchText);

}
