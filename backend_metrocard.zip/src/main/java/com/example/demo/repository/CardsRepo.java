package com.example.demo.repository;

import java.util.List;

import org.apache.catalina.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Cards;

import jakarta.transaction.Transactional;

@Repository
public interface CardsRepo extends JpaRepository<Cards,Long>{
	
	List<Cards> findByUser(User user);
	

	@Transactional
	@Modifying
	@Query(value="update cards set balance=balance+?2 where user_id=?1",nativeQuery=true)
	public  int updateCardBalance(int userId,int balance);
	
	public Cards findByUserUserId(Long userId);

}
