package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Users;

public interface UsersService {
	
	public Users addUser(Users user);
	public Users loginUser(Users user);
	public Users findByUsername(String username);
	public Users findByCity(String city);
	public Users findByPhone(String phone);
	public Users findByEmailId(String email);
	public List<Users> getAllUsers();
	public Users updateAllUsers(Integer userId,Users user);
	public List<Users> deleteUser(Integer userId);
	public Users getUserById(Integer userId);
	public List<Users> searchUsers(String searchText);


}
