package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Cards;
import com.example.demo.entity.Users;

public interface CardsService {

	public Cards addCard(Cards cards);
	
	public void updateUsernameByCardid(Long cardId,String username);
	
	//public List<Cards> getCardsByUser(Users user);
		
	public void deleteCard(Long cardId) ;
	
	 public List<Cards> getAllCards();
	 
	 public int updateCardBalance(int userId, int newBalance);
	 
	 public Cards getCardById(Long cardId) ;
	 public Cards addCardByUserId(Cards card,int userId);
	 public Cards setActiveCardStatus(Long cardId);
	 public Cards setInActiveCardStatus(Long cardId);
	 
	 public Cards getCardByUserId(Long userId);
	 
	 
	 
	 
}
