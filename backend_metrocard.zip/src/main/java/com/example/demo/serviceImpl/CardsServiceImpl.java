package com.example.demo.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Cards;
import com.example.demo.entity.Users;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.CardsRepo;
import com.example.demo.repository.UsersRepo;
import com.example.demo.service.CardsService;
import com.example.demo.service.UsersService;


@Service
public class CardsServiceImpl implements CardsService{

	@Autowired
	CardsRepo cardsRepo;
	
	@Autowired
	UsersRepo usersRepo;
	
	@Autowired
	UsersService userService;
	
	@Override
	public Cards addCard(Cards cards) {
		// TODO Auto-generated method stub
		cards.setExpiry(LocalDateTime.now().plusYears(5));
		//cards.setStatus(Cards.Status.ACTIVE);
		return cardsRepo.save(cards);
	}
	@Override
	public void updateUsernameByCardid(Long cardId, String username) {
		// TODO Auto-generated method stub
		Cards card = cardsRepo.findById(cardId).orElseThrow(() -> 
        new IllegalArgumentException("Card ID not found: " + cardId));
    
    // Retrieve the associated user
    Users user = card.getUser();
    if (user == null) {
        throw new IllegalArgumentException("No user associated with the card ID: " + cardId);
    }

    user.setUsername(username);

    // Save the updated user back to the database
    usersRepo.save(user);
	}


	

//	@Override
//	public List<Cards> getCardsByUser(Users user) {
//		// TODO Auto-generated method stub
//		return cardsRepo.findByUser(user);
//	}

	@Override
	public void deleteCard(Long cardId) {
		// TODO Auto-generated method stub
		if(cardsRepo.existsById(cardId))
		{
			cardsRepo.deleteById(cardId);
		}
		else
		{
			throw new ResourceNotFoundException("","",cardId);
		}
		
	}

	@Override
	public List<Cards> getAllCards() {
		// TODO Auto-generated method stub
		return cardsRepo.findAll();
	}

	@Override
	public int updateCardBalance(int userId, int newBalance) {
		// TODO Auto-generated method stub
	return 	cardsRepo.updateCardBalance(userId, newBalance);
		
		
	}

	@Override
	public Cards getCardById(Long cardId) {
		// TODO Auto-generated method stub
		return cardsRepo.findById(cardId).orElseThrow();
	}
	@Override
	public Cards addCardByUserId(Cards card, int userId) {
		// TODO Auto-generated method stub
		Users user1=userService.getUserById(userId);
		card.setUser(user1);
		card.setExpiry(LocalDateTime.now().plusYears(5));
		return cardsRepo.save(card);
	}
	@Override
	public Cards setActiveCardStatus(Long cardId) {
		// TODO Auto-generated method stub
		Cards cards=getCardById(cardId);
		cards.setStatus("ACTIVE");
		return cardsRepo.save(cards);
	}
	@Override
	public Cards setInActiveCardStatus(Long cardId) {
		// TODO Auto-generated method stub
		Cards cards=getCardById(cardId);
		cards.setStatus("INACTIVE");
		return cardsRepo.save(cards);
	}
	@Override
	public Cards getCardByUserId(Long userId) {
		// TODO Auto-generated method stub
		return cardsRepo.findByUserUserId(userId);
	}
	


	
	
}
