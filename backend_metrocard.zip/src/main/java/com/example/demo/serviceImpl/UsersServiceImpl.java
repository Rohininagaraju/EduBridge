package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Users;
import com.example.demo.repository.UsersRepo;
import com.example.demo.service.UsersService;

@Service
public class UsersServiceImpl implements UsersService{

	@Autowired
	private UsersRepo usersRepo;
	@Override
	public Users addUser(Users user) {
		// TODO Auto-generated method stub
		return usersRepo.save(user);
	
	}
	@Override
	public Users loginUser(Users user) {
		// TODO Auto-generated method stub
		return usersRepo.findByUsernameAndUserPassword(user.getUsername(), user.getUserPassword());
	}
	@Override
	public Users findByUsername(String username) {
		// TODO Auto-generated method stub
		return usersRepo.findByUsername(username);
	}
	@Override
	public Users findByCity(String city) {
		// TODO Auto-generated method stub
		return usersRepo.findByCity(city);
	}
	@Override
	public Users findByPhone(String phone) {
		// TODO Auto-generated method stub
		return usersRepo.findByPhone(phone);
	}
	@Override
	public Users findByEmailId(String email) {
		// TODO Auto-generated method stub
		return usersRepo.findByEmailId(email);
	}
	@Override
	public List<Users> getAllUsers() {
		// TODO Auto-generated method stub
		return usersRepo.findAll();
	}
	@Override
	public List<Users> deleteUser(Integer userId) {
		// TODO Auto-generated method stub
		Users user=usersRepo.findById(userId).get();//To check if it is present
		usersRepo.deleteById(user.getUserId());//The object is passed here
		return usersRepo.findAll();
	}
	@Override
	public Users updateAllUsers(Integer userId,Users user) {
		// TODO Auto-generated method stub
		Users user1=usersRepo.findById(userId).get();
		user1.setUsername(user.getUsername());
		user1.setCity(user.getCity());
        user1.setEmailId(user.getEmailId());	
        user1.setPhone(user.getPhone());
        user1.setUserPassword(user.getUserPassword());
		return usersRepo.save(user1);
	}
	@Override
	public Users getUserById(Integer userId) {
		// TODO Auto-generated method stub
		return usersRepo.findById(userId).get();
	}
	@Override
	public List<Users> searchUsers(String searchText) {
		// TODO Auto-generated method stub
		return usersRepo.searchUsers(searchText);
	}
	

}
