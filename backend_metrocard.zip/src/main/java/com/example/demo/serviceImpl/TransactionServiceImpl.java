package com.example.demo.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Transaction;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.TransactionRepo;
import com.example.demo.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService {

    @Autowired
    private TransactionRepo transactionRepository;

    @Override
    public Transaction addTransaction(Transaction transaction) {
        // Validate transaction details
        if (transaction.getCard() == null) {
            throw new IllegalArgumentException("Card is required for a transaction.");
        }
        if (transaction.getTrans_amount() == null || transaction.getTrans_amount() <= 0) {
            throw new IllegalArgumentException("Transaction amount must be greater than 0.");
        }

        // Save transaction
        return transactionRepository.save(transaction);
    }

    @Override
    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    @Override
    public Transaction getTransactionById(Long transaction_id) {
        return transactionRepository.findById(transaction_id)
                .orElseThrow(() -> new ResourceNotFoundException("", "", transaction_id));
    }

//    @Override
//    public List<Transaction> getTransactionsByCard_Id(Long cardId) {
//        return transactionRepository.findByCard_Id(cardId);
//    }

    @Override
    public void deleteTransactionById(Long transaction_id) {
        if (!transactionRepository.existsById(transaction_id)) {
            throw new ResourceNotFoundException("", "", transaction_id);
        }
        transactionRepository.deleteById(transaction_id);
    }
}

