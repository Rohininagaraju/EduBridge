package com.example.demo.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="transaction")

public class Transaction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long transaction_id;
	
	@ManyToOne
	@JoinColumn(name="card_id",nullable=false)
	private Cards card;
	
	@ManyToOne
	@JoinColumn(name="userId",nullable=false)
	private Users user;
	
	@Enumerated(EnumType.STRING)
	@Column(name="transaction_type",nullable=false,length=10)
	private Transaction_type transaction_type;

	@Column(name="amount",nullable=false)
	private Double trans_amount;
	
	 @Column(name = "transaction_time", nullable = false)
	    private LocalDateTime transactionTime;
	@Column(name="source",nullable=false)
	private String source;
	@Column(name="destination",nullable=false)
	private String destination;
	enum Transaction_type{
		RECHARGED,
		DEDUCTED
		
	}

	public Long getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(Long transaction_id) {
		this.transaction_id = transaction_id;
	}

	public Cards getCard() {
		return card;
	}

	public void setCard(Cards card) {
		this.card = card;
	}

	public Transaction_type getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(Transaction_type transaction_type) {
		this.transaction_type = transaction_type;
	}

	public Double getTrans_amount() {
		return trans_amount;
	}

	public void setTrans_amount(Double trans_amount) {
		this.trans_amount = trans_amount;
	}

	public LocalDateTime getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(LocalDateTime transactionTime) {
		this.transactionTime = transactionTime;
	}
	
	
}
