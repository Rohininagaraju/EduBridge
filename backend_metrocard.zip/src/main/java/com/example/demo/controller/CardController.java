package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Cards;
import com.example.demo.entity.Users;
import com.example.demo.service.CardsService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/cards")

public class CardController {

	
	    @Autowired
	    private CardsService cardsService;

	    // Add a new card
	    @PostMapping
	    public ResponseEntity<Cards> addCard(@RequestBody Cards card) {
	        Cards createdCard = cardsService.addCard(card);
	        return ResponseEntity.ok(createdCard);
	    }
	    @PostMapping("/{userId}")
	    public ResponseEntity<Cards> addCardByUserId(@PathVariable int userId,@RequestBody Cards card) {
	        Cards createdCard = cardsService.addCardByUserId(card,userId);
	        
	        return ResponseEntity.ok(createdCard);
	        
	    }

	    // Get all cards
	    @GetMapping
	    public ResponseEntity<List<Cards>> getAllCards() {
	        List<Cards> cards = cardsService.getAllCards();
	        return ResponseEntity.ok(cards);
	    }

	    // Get card by ID
	    @GetMapping("/{id}")
	    public ResponseEntity<Cards> getCardById(@PathVariable Long id) {
	        Cards card = cardsService.getCardById(id);
	        return ResponseEntity.ok(card);
	    }

//	    // Get cards by user
//	    @PostMapping("/byuser")
//	    public ResponseEntity<List<Cards>> getCardsByUser(@RequestBody Users user) {
//	        List<Cards> cards = cardsService.getCardsByUser(user);
//	        return ResponseEntity.ok(cards);
//	    }

	    @GetMapping("/getcardsbyuserid/{userId}")
	    public ResponseEntity<Cards> getCardByUserId(@PathVariable Long userId){
	    	Cards card=cardsService.getCardByUserId(userId);
	    	return ResponseEntity.ok(card);
	    	
	    }
	    // Update the balance of a card
	    @PutMapping("/{userId}/{balance}")
	    public ResponseEntity<Integer> updateCardBalance(@PathVariable int userId, @PathVariable int balance,@RequestBody Cards card) {
	        int updatedCard = cardsService.updateCardBalance(userId, balance);
	        return ResponseEntity.ok(updatedCard);
	    }

	    // Update the username associated with a card
	    @PutMapping("/{id}/username")
	    public ResponseEntity<Void> updateUsernameByCardId(@PathVariable Long id, @RequestParam String username) {
	        cardsService.updateUsernameByCardid(id, username);
	        return ResponseEntity.ok().build();
	    }

	    // Delete a card
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteCard(@PathVariable Long id) {
	        cardsService.deleteCard(id);
	        return ResponseEntity.noContent().build();
	    }
	    @PutMapping("/active/{cardId}")
	    public ResponseEntity<Cards> setActiveCardStatus(@PathVariable Long cardId,@RequestBody Cards card)
	    {
	    	return new ResponseEntity<Cards> (cardsService.setActiveCardStatus(cardId),HttpStatus.OK);
	    	
	    }
	    @PutMapping("/inactive/{cardId}")
	    public ResponseEntity<Cards> setInActiveCardStatus(@PathVariable Long cardId,@RequestBody Cards card)
	    {
	    	return new ResponseEntity<Cards> (cardsService.setInActiveCardStatus(cardId),HttpStatus.OK);
	    	
	    }
	}

